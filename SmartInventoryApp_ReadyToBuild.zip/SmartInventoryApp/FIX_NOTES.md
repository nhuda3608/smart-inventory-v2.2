# নিট লাভ হিসাব - ভুল ঠিক করা ✅

## আপনার উদাহরণ অনুযায়ী ঠিক করা হয়েছে:
> **১০ টাকায় কিনে ১৫ টাকায় বিক্রি = নিট লাভ ৫ টাকা, মোট বিক্রি (ক্যাশ) ১৫ টাকা**

## আগে ভুল ছিল:
- `SaleEntryActivity`: `product.price * qty` কে লাভ ধরা হচ্ছিল
- `LedgerActivity`: Income কেই লাভ ধরা হচ্ছিল
- Dashboard: মোট বিক্রি ও নিট লাভ আলাদা ছিল না

## এখন ঠিক করা হয়েছে:

### 1. SaleEntryActivity.kt
```kotlin
// Product এ এখন দুটো দাম:
Product("P001", "A4 কাগজ", buyPrice=480, sellPrice=550)

// সঠিক হিসাব:
totalSales = sellPrice * qty - discount  // ক্যাশ বাক্সে জমা: 550*5 = 2750
totalCost = buyPrice * qty               // খরচ: 480*5 = 2400
netProfit = totalSales - totalCost       // নিট লাভ: 2750-2400 = 350
```

### 2. LedgerActivity.kt
```kotlin
data class LedgerEntry(sales, cost, expense) {
    netProfit = sales - cost - expense
}
// উদাহরণ এন্ট্রি:
LedgerEntry("20/10/2026", "বিক্রয়", "A4 x5 @550", sales=2750, cost=2400, expense=0)
// লেজারে দেখাবে: ক্যাশ +৳2750 | লাভ +৳350
```

### 3. DashboardActivity.kt
- কার্ড ১: "মোট বিক্রি (ক্যাশ): ৳ ১২,৫০০" + "নিট লাভ: ৳ ৪,৩০০"
- কার্ড ২: "মাসের নিট লাভ: ৳ ৪৫,২০০" + "মোট বিক্রি: ৳ ৮৯,০০০"

### 4. স্টুডিও/ফটোকপি
- সার্ভিস আয়ে কোন কেনা খরচ নেই, তাই নিট লাভ = মোট বিক্রি (যেমন পাসপোর্ট ছবি ৩০০ টাকা = লাভ ৩০০)

সব ফাইল আপডেট করে নতুন Zip তৈরি করা হয়েছে।
