Smart Inventory v2.1 - সব ফাইল এক ফোল্ডারে
========================================

1) SmartInventoryApp/ 
   -> সম্পূর্ণ Android Studio প্রজেক্ট (APK বানানোর জন্য এটাই লাগবে)
   -> Android Studio তে Open করুন -> Build -> Build APK
   -> GitHub এ আপলোড করলে auto APK হবে (.github/workflows/build.yml)

   ভিতরে:
   - app/src/main/AndroidManifest.xml (v2.1, INTERNET+SMS+CAMERA)
   - app/build.gradle (Firebase + Chart)
   - app/src/main/java/bd/smartinventory/app/ (7টি Activity - সব ঠিক করা)
     * LoginActivity.kt (Google + OTP)
     * OtpVerifyActivity.kt (6 digit)
     * DashboardActivity.kt (মোট বিক্রি + নিট লাভ আলাদা)
     * SaleEntryActivity.kt (নিট লাভ = বিক্রয় - কেনা) FIXED
     * StockEntryActivity.kt
     * IncomeActivity.kt (ST/PC)
     * LedgerActivity.kt (ক্যাশ + নিট লাভ) FIXED
   - app/src/main/res/layout/ (3টি XML)
   - settings.gradle, build.gradle, gradlew

2) Reference_Files/
   -> পুরনো VBA txt, SalesPlan.md, HTML preview, গাইড

3) APK বানানোর গাইড: SmartInventoryApp/README_WORKFLOW_FIX.md দেখুন

নিট লাভ হিসাব FIXED: 10 টাকায় কিনে 15 টাকায় বেচলে লাভ 5, ক্যাশ 15
