# Smart Inventory v2.0 → v2.1 আপডেট - কী কী করা হয়েছে

## আপনার পুরনো অ্যাপ (v2.0) এ কী ছিল:
- Package: `bd.smartinventory.app`
- VersionCode: 1, VersionName: 2.0
- minSdk 21, targetSdk 34
- শুধু 1টি Activity: `MainActivity`
- Permission: শুধু WRITE_EXTERNAL_STORAGE
- সমস্যা: INTERNET permission ছিল না, তাই Google Login / OTP কাজ করত না

## নতুন আপডেট (v2.1) এ কী যোগ করা হয়েছে:

### 1. AndroidManifest.xml আপডেট
- **VersionCode 1 → 2, VersionName 2.0 → 2.1**
- **INTERNET + ACCESS_NETWORK_STATE** যোগ - Google Login ও অনলাইন Dashboard এর জন্য বাধ্যতামূলক
- **RECEIVE_SMS + READ_SMS** - OTP অটো-রিড এর জন্য
- **CAMERA** - বারকোড স্ক্যান ও পণ্যের ছবি
- **READ_MEDIA_IMAGES** - Android 13+ এর জন্য
- **3টি নতুন Activity:**
  - `LoginActivity` - Google + Phone OTP + পুরনো ইউজার/পাসওয়ার্ড
  - `OtpVerifyActivity` - 6 ডিজিট OTP ভেরিফিকেশন
  - `DashboardActivity` - নতুন ড্যাশবোর্ড

### 2. লগইন সিস্টেম (আপনার চাওয়া অনুযায়ী)
আপনার পুরনো VBA `modAuth.txt` এ ছিল:
```
HashPass() দিয়ে পাসওয়ার্ড হ্যাশ
FindUserRow() দিয়ে ইউজার খোঁজা
gRole = Admin/Operator
```

নতুন সিস্টেমে:
- **Option A: Google দিয়ে লগইন** - এক ক্লিকে (Firebase Auth)
- **Option B: ফোন নম্বর + OTP** - 6 ডিজিট কোড, অটো-রিড
- **Option C: পুরনো সিস্টেম** - আগের মতো ইউজার/পাসওয়ার্ড ও থাকবে (Backward Compatibility)
- সব লগইন একই `gUser`, `gRole` এ সেভ হবে - তাই বাকি কোড ভাঙবে না

### 3. নতুন ড্যাশবোর্ড
পুরনো Dashboard এ ছিল: আজকের বিক্রয়, মাসের লাভ, স্টকের মূল্য, কম স্টক
নতুন Dashboard এ যোগ হবে:
- উপরে 4টি কার্ড (আগের মতো) + রঙিন আইকন
- 12 মাসের আয়-ব্যয়-লাভ চার্ট (MPAndroidChart)
- কম স্টকের লাল এলার্ট
- ক্যালেন্ডার ভিউ - কোন দিনে কত বিক্রয়
- দ্রুত বাটন: নতুন বিক্রয় | স্টক এন্ট্রি | ইনভয়েস

### 4. পরবর্তী ধাপ - আপনার করণীয়
1. এই `AndroidManifest.xml` টি আপনার প্রজেক্টে `app/src/main/` এ Replace করুন
2. `build.gradle` এ Firebase যোগ করুন (আমি ফাইল বানিয়ে দিয়েছি)
3. Google Console থেকে `google-services.json` নিন

আপনি চাইলে আমি পুরো `LoginActivity.kt` + `DashboardActivity.kt` + `build.gradle` ফাইলগুলোও বানিয়ে দেব।
