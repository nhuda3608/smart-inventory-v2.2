# Smart Inventory v2.1 - আপডেট সম্পূর্ণ ✅

## কী কী করা হয়েছে (আপনার চাওয়া অনুযায়ী)

### 1. লগইন সিস্টেম - Social Login ✅
**পুরনো (VBA modAuth.txt):**
- শুধু ইউজার/পাসওয়ার্ড + HashPass()
- gUser, gRole = Admin/Operator

**নতুন (v2.1):**
- **Google Sign-In** - 1 ক্লিকে (Firebase Auth)
- **Phone OTP** - +88 নম্বরে 6 ডিজিট কোড, অটো-রিড (SMS Retriever)
- **পুরনো সিস্টেম ও থাকবে** - Backward compatible, HashPass() Kotlin এ কনভার্ট করা
- Demo OTP: `123456` দিলে Firebase ছাড়াও টেস্ট করা যাবে

**ফাইল:**
- `AndroidManifest.xml` - INTERNET, RECEIVE_SMS permission + 3 নতুন Activity
- `LoginActivity.kt` - 3টি লগইন একসাথে
- `OtpVerifyActivity.kt` - OTP ভেরিফিকেশন + 60s Timer

### 2. নতুন ড্যাশবোর্ড ✅
**পুরনো:** আজকের বিক্রয়, মাসের লাভ, স্টক মূল্য, কম স্টক
**নতুন:**
- 4টি রঙিন কার্ড + % বৃদ্ধি
- দ্রুত কাজ 4 বাটন (বিক্রয়/স্টক/ইনভয়েস/স্টুডিও)
- 12 মাসের Bar Chart (MPAndroidChart)
- কম স্টক লাল এলার্ট
- ক্যালেন্ডার - তারিখ ক্লিক করে দিনের বিক্রয়

**ফাইল:**
- `DashboardActivity.kt`
- `activity_dashboard.xml`
- `dashboard_preview.html` - ব্রাউজারে প্রিভিউ (উপরে দেখুন)

### 3. বিক্রয় এন্ট্রি (নতুন) ✅
**পুরনো (SaleEntry.txt):** কোড/নাম লিখলেই দাম অটো, QuickAddProduct
**নতুন:**
- AutoComplete সাজেশন (FindProductRow এর মতো)
- বারকোড স্ক্যান বাটন (Camera + ML Kit)
- পরিমাণ + ছাড়
- কার্ট + মোট হিসাব
- সেভ + প্রিন্ট/PDF

**ফাইল:**
- `SaleEntryActivity.kt`
- `activity_sale_entry.xml`

## কীভাবে ব্যবহার করবেন

1. **Android Studio** খুলুন
2. `app/src/main/AndroidManifest.xml` → আমার নতুন ফাইল দিয়ে Replace
3. `app/build.gradle` → আমার নতুন dependencies যোগ করুন
4. Firebase Console (console.firebase.google.com) → নতুন প্রজেক্ট → Android App `bd.smartinventory.app` যোগ → `google-services.json` ডাউনলোড করে `app/` ফোল্ডারে রাখুন
5. **Phone Auth** Enable করুন (Firebase → Authentication → Sign-in method)
6. Run করুন!

## ডেমো লগইন (Firebase ছাড়া টেস্ট)
- ইউজার: `admin` / পাস: `1234` → পুরনো সিস্টেম
- Phone: যেকোনো নম্বর → OTP: `123456`

## পরবর্তী আপডেট (চাইলে বানিয়ে দেব)
- StockEntryActivity (কেনা + স্টক বাড়া)
- StudioIncome / PhotocopyIncome আলাদা শিট
- DailyLedger + Monthly Report PDF
- Backup & Restore

বলুন, কোনটি আগে বানাব?
